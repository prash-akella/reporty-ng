package testcoverage2;

import org.testng.annotations.Test;
import org.testng.Assert;

/**
 * Unit test for simple App.
 */
@Test
public class AppTest {

    public void testApp()
    {
        Assert.assertEquals(true, true);
    }
}
