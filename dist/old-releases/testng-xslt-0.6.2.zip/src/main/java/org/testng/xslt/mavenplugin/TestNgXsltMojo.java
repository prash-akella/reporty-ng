package org.testng.xslt.mavenplugin;

import org.apache.maven.project.MavenProject;
import org.apache.maven.reporting.AbstractMavenReport;
import org.apache.maven.reporting.MavenReportException;
import org.codehaus.doxia.site.renderer.SiteRenderer;

import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.util.Locale;

/**
 * @author Cosmin Marginean, Apr 1, 2008
 * @goal xslt
 */
public class TestNgXsltMojo extends AbstractMavenReport {

    /**
     * @parameter expression="${project}"
     * @required
     * @readonly
     */
    private MavenProject project;

    /**
     * @parameter expression="${project.reporting.outputDirectory}"
     * @required
     */
    private String outputDirectory;

    /**
     * @parameter
     */
    private String cssFile;

    protected void executeReport(Locale locale) throws MavenReportException {
        try {
            //TODO: This is just a workaround until clarification of Saxon integration
            Thread.currentThread().setContextClassLoader(net.sf.saxon.TransformerFactoryImpl.class.getClassLoader());

            System.setProperty("javax.xml.transform.TransformerFactory", "net.sf.saxon.TransformerFactoryImpl");
            TransformerFactory factory = TransformerFactory.newInstance();
            String outputDir = getHtmlOutputDir();
            new File(outputDir).mkdirs();
            StreamSource inputSource = new StreamSource(getTestNgResultsXmlPath());
            Transformer transformer = factory.newTransformer(new StreamSource(getClass().getResourceAsStream("/testng-results.xsl")));

            transformer.setParameter("testNgXslt.outputDir", outputDir);
            if (cssFile != null && cssFile.trim().length() > 0) {
                transformer.setParameter("testNgXslt.cssFile", cssFile);
            }

            transformer.transform(inputSource, new StreamResult(new FileOutputStream(outputDir + File.separator + "index.html")));
        } catch (FileNotFoundException fnfException) {
            throw new MavenReportException("An error occured during TestNG XSLT transformation", fnfException);
        } catch (TransformerConfigurationException tcException) {
            throw new MavenReportException("An error occured during TestNG XSLT transformation", tcException);
        } catch (TransformerException tException) {
            throw new MavenReportException("An error occured during TestNG XSLT transformation", tException);
        }
    }

    private String getHtmlOutputDir() {
        return getProject().getBasedir()
                + File.separator + getOutputDirectory()
                + File.separator + "testng-xslt";
    }

    private String getTestNgResultsXmlPath() {
        return getProject().getBasedir()
                + File.separator + "target"
                + File.separator + "surefire-reports"
                + File.separator + "testng-results.xml";
    }

    public String getDescription(Locale locale) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public String getName(Locale locale) {
        return "TestNG XSLT Results";
    }

    protected String getOutputDirectory() {
        return outputDirectory;
    }

    public String getOutputName() {
        return "testng-xslt" + File.separator + "index";
    }

    protected MavenProject getProject() {
        return project;
    }

    protected SiteRenderer getSiteRenderer() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    public boolean isExternalReport() {
        return true;
    }
}
